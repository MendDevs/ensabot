# chatgpt-based-chatbot-with-kotlin
This is a Chatbot with the ChatGPT API using Kotlin

 ***Resources***
  - ChatGPT API (Create Completion): https://platform.openai.com/docs/guides/text-generation/completions-api
                (See full completion documentation here): https://platform.openai.com/docs/api-reference/completions
    
  - okHTTP Library : https://square.github.io/okhttp/
    
